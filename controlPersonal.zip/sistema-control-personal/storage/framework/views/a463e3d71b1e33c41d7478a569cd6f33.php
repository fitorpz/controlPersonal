<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between max-w-5xl mx-auto w-full">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Usuarios del Sistema')); ?>

            </h2>

            
            <a href="<?php echo e(route('usuarios.create')); ?>"
                class="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-white" fill="none"
                    viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" />
                </svg>
                Nuevo Usuario
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-10">
        <div class="max-w-5xl mx-auto px-6">
            
            <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-6 border border-green-300 text-sm">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            
            <div class="bg-white shadow-md rounded-lg border border-gray-200 overflow-hidden">
                
                <div class="overflow-x-auto">
                    <table class="table-auto min-w-max border-collapse">
                        <thead>
                            <tr class="bg-gray-100 text-gray-700 text-sm font-semibold">
                                <th class="px-4 py-3 text-left border-b">ID</th>
                                <th class="px-4 py-3 text-left border-b">Nombre</th>
                                <th class="px-4 py-3 text-left border-b">Correo</th>
                                <th class="px-4 py-3 text-left border-b">Rol</th>
                                <th class="px-4 py-3 text-left border-b">Estado</th>
                                <th class="px-4 py-3 text-center border-b w-44">Acciones</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="px-4 py-3 text-sm text-gray-800 border-b"><?php echo e($usuario->id); ?></td>
                                <td class="px-4 py-3 text-sm text-gray-800 border-b whitespace-nowrap">
                                    <?php echo e($usuario->nombres); ?> <?php echo e($usuario->apellido_paterno); ?>

                                </td>
                                <td class="px-4 py-3 text-sm text-gray-800 border-b whitespace-nowrap"><?php echo e($usuario->email); ?></td>
                                <td class="px-4 py-3 text-sm text-gray-800 border-b capitalize whitespace-nowrap"><?php echo e($usuario->rol); ?></td>
                                <td class="px-4 py-3 text-sm border-b whitespace-nowrap">
                                    <span class="px-2 py-1 rounded-full text-xs font-medium
                                            <?php echo e(strtoupper($usuario->estado) === 'ACTIVO'
                                                ? 'bg-green-100 text-green-700'
                                                : 'bg-red-100 text-red-700'); ?>">
                                        <?php echo e(ucfirst(strtolower($usuario->estado))); ?>

                                    </span>
                                </td>
                                <td class="px-4 py-3 text-center border-b whitespace-nowrap">
                                    <div class="flex justify-center items-center gap-4">
                                        <a href="<?php echo e(route('usuarios.edit', $usuario)); ?>"
                                            class="flex items-center text-blue-600 hover:text-blue-800 font-medium">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none"
                                                viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                    d="M15.232 5.232l3.536 3.536m-2.036-1.5l-9.192 9.192a2 2 0 01-.878.515l-3.39.848a.5.5 0 01-.606-.606l.848-3.39a2 2 0 01.515-.878l9.192-9.192a2 2 0 012.828 0z" />
                                            </svg>
                                            Editar
                                        </a>
                                        <form action="<?php echo e(route('usuarios.destroy', $usuario)); ?>" method="POST"
                                            onsubmit="return confirm('¿Desactivar este usuario?')" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                class="flex items-center text-red-600 hover:text-red-800 font-medium">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none"
                                                    viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="M6 18L18 6M6 6l12 12" />
                                                </svg>
                                                Desactivar
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="px-4 py-5 text-center text-gray-600">
                                    No hay usuarios registrados.
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="px-4 py-3 border-t border-gray-100">
                    <?php echo e($usuarios->links()); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\controlPersonal\sistema-control-personal\resources\views/users/index.blade.php ENDPATH**/ ?>