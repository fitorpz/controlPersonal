

<?php $__env->startSection('title', 'Parámetros Personalizados por Empleado'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4" style="max-width: 700px;">
    <h3 class="mb-4">
        Parámetros Personalizados – <?php echo e($empleado->user->name ?? 'Empleado'); ?>

    </h3>

    <div class="alert alert-info">
        <strong>Nota:</strong> Si dejas un campo vacío, se aplicará el valor general.
    </div>

    <form method="POST" action="<?php echo e(route('parametros.empleado.update', $empleado)); ?>">
        <?php echo csrf_field(); ?>

        <div class="table-responsive">
            <table class="table table-bordered align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Clave</th>
                        <th>Descripción</th>
                        <th>Valor General</th>
                        <th>Personalizado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $parametrosGenerales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parametro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $clave = $parametro->clave;
                    $valorPersonalizado = $parametrosEmpleado[$clave]->valor ?? null;
                    ?>
                    <tr>
                        <td><strong><?php echo e($clave); ?></strong></td>
                        <td><?php echo e($parametro->descripcion ?? '-'); ?></td>
                        <td><?php echo e($parametro->valor !== null ? number_format($parametro->valor, 2) . ' Bs' : '-'); ?></td>
                        <td>
                            <input type="number"
                                name="<?php echo e($clave); ?>"
                                class="form-control"
                                value="<?php echo e(old($clave, $valorPersonalizado)); ?>"
                                step="0.01"
                                min="0"
                                placeholder="Ej: 100.00">
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-between mt-4">
            <a href="<?php echo e(route('parametros.index')); ?>" class="btn btn-secondary">Volver</a>
            <button type="submit" class="btn btn-success">Guardar Cambios</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\controlPersonal\resources\views/parametros/empleado.blade.php ENDPATH**/ ?>