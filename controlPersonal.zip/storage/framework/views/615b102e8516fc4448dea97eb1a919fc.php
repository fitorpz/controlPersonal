

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Editar Horario</h2>

    <form action="<?php echo e(route('horarios.update', $horario)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>Empleado (opcional)</label>
            <select name="empleado_id" class="form-control">
                <option value="">Horario general</option>
                <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($empleado->id); ?>" <?php echo e($horario->empleado_id == $empleado->id ? 'selected' : ''); ?>>
                    <?php echo e($empleado->user->name ?? 'Sin nombre'); ?> (<?php echo e($empleado->ci); ?>)
                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Hora de Entrada</label>
            <input type="time" name="hora_entrada" class="form-control" value="<?php echo e($horario->hora_entrada); ?>" required>
        </div>

        <div class="mb-3">
            <label>Hora de Salida</label>
            <input type="time" name="hora_salida" class="form-control" value="<?php echo e($horario->hora_salida); ?>" required>
        </div>

        <div class="mb-3">
            <label>Nombre del Turno (opcional)</label>
            <input type="text" name="nombre_turno" class="form-control" value="<?php echo e($horario->nombre_turno); ?>">
        </div>

        <button type="submit" class="btn btn-success">Actualizar Horario</button>
        <a href="<?php echo e(route('horarios.index')); ?>" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\controlPersonal\resources\views/horarios/edit.blade.php ENDPATH**/ ?>