

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <!-- Bienvenida -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h4 class="mb-0">Bienvenido, <?php echo e(auth()->user()->nombre); ?></h4>
        </div>
    </div>

    <!-- Sección de Reportes -->
    <h5 class="mb-3">Reportes del Sistema</h5>
    <div class="row g-4">
        <!-- Reporte de Ventas -->
        <div class="col-md-4">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body text-center">
                    <i class="fa-solid fa-chart-line fa-2x text-primary mb-3"></i>
                    <h5 class="card-title">Reporte de Ventas</h5>
                    <p class="card-text">Consulta todas las ventas realizadas y su desglose.</p>
                    <a href="<?php echo e(route('reportes.ventas.index')); ?>" class="btn btn-outline-primary">Ver Reporte</a>
                </div>
            </div>
        </div>

        <!-- Reporte de Clientes -->
        <div class="col-md-4">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body text-center">
                    <i class="fa-solid fa-users fa-2x text-success mb-3"></i>
                    <h5 class="card-title">Reporte de Clientes</h5>
                    <p class="card-text">Información detallada y estado de tus clientes.</p>
                    <a href="#" class="btn btn-outline-success">Ver Reporte</a>
                </div>
            </div>
        </div>

        <!-- Reporte de Inventario -->
        <div class="col-md-4">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body text-center">
                    <i class="fa-solid fa-boxes-stacked fa-2x text-warning mb-3"></i>
                    <h5 class="card-title">Reporte de Inventario</h5>
                    <p class="card-text">Visualiza productos disponibles por almacén.</p>
                    <a href="#" class="btn btn-outline-warning">Ver Reporte</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ferr_limpio\resources\views/dashboard.blade.php ENDPATH**/ ?>